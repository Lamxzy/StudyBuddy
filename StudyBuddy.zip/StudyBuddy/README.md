# StudyBuddy – Student Task Planner (AUSU-SFE401)

An Android app (Java + XML) that helps students plan assignments and study tasks.
Data is stored locally with SQLite.

## Activities (4)
| Activity | Layout | Purpose |
|---|---|---|
| SplashActivity | activity_splash.xml | Branding screen, auto-opens MainActivity |
| MainActivity | activity_main.xml, item_task.xml | List of tasks, tick to complete, + button |
| AddTaskActivity | activity_add_task.xml | Add or edit a task (title, description, date picker, priority) |
| TaskDetailActivity | activity_task_detail.xml | View, mark done/pending, edit, delete |

## Other classes
Task (model), DbHelper (SQLite CRUD), TaskAdapter (custom ListView adapter).

## Run
1. Android Studio -> File -> Open -> select this folder.
2. Let Gradle sync, then Run on an emulator or phone (API 24+).

## Suggested split for a group of 10
1. Project setup, Gradle, Git repo
2. SplashActivity + theme/colors
3. MainActivity UI (activity_main.xml)
4. MainActivity logic + empty state
5. item_task.xml + TaskAdapter
6. AddTaskActivity UI
7. AddTaskActivity logic (validation, date picker)
8. TaskDetailActivity UI + logic
9. Task + DbHelper (database)
10. Testing, screenshots, documentation/report
