package com.ausu.studybuddy;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "studybuddy.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE = "tasks";

    public DbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "title TEXT NOT NULL, "
                + "description TEXT, "
                + "due_date TEXT, "
                + "priority INTEGER, "
                + "done INTEGER DEFAULT 0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    private ContentValues toValues(Task t) {
        ContentValues v = new ContentValues();
        v.put("title", t.title);
        v.put("description", t.description);
        v.put("due_date", t.dueDate);
        v.put("priority", t.priority);
        v.put("done", t.done ? 1 : 0);
        return v;
    }

    private Task fromCursor(Cursor c) {
        Task t = new Task();
        t.id = c.getLong(c.getColumnIndexOrThrow("id"));
        t.title = c.getString(c.getColumnIndexOrThrow("title"));
        t.description = c.getString(c.getColumnIndexOrThrow("description"));
        t.dueDate = c.getString(c.getColumnIndexOrThrow("due_date"));
        t.priority = c.getInt(c.getColumnIndexOrThrow("priority"));
        t.done = c.getInt(c.getColumnIndexOrThrow("done")) == 1;
        return t;
    }

    public long insert(Task t) {
        return getWritableDatabase().insert(TABLE, null, toValues(t));
    }

    public void update(Task t) {
        getWritableDatabase().update(TABLE, toValues(t), "id = ?",
                new String[]{String.valueOf(t.id)});
    }

    public void delete(long id) {
        getWritableDatabase().delete(TABLE, "id = ?", new String[]{String.valueOf(id)});
    }

    public void setDone(long id, boolean done) {
        ContentValues v = new ContentValues();
        v.put("done", done ? 1 : 0);
        getWritableDatabase().update(TABLE, v, "id = ?", new String[]{String.valueOf(id)});
    }

    public Task getById(long id) {
        Cursor c = getReadableDatabase().query(TABLE, null, "id = ?",
                new String[]{String.valueOf(id)}, null, null, null);
        Task t = null;
        if (c.moveToFirst()) t = fromCursor(c);
        c.close();
        return t;
    }

    public List<Task> getAll() {
        List<Task> list = new ArrayList<>();
        Cursor c = getReadableDatabase().query(TABLE, null, null, null, null, null,
                "done ASC, due_date ASC");
        while (c.moveToNext()) list.add(fromCursor(c));
        c.close();
        return list;
    }
}
