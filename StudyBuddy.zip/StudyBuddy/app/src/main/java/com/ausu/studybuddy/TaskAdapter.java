package com.ausu.studybuddy;

import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import java.util.List;

public class TaskAdapter extends ArrayAdapter<Task> {

    private final DbHelper db;
    private final String[] priorityNames;

    public TaskAdapter(@NonNull Context context, @NonNull List<Task> tasks, DbHelper db) {
        super(context, 0, tasks);
        this.db = db;
        this.priorityNames = context.getResources().getStringArray(R.array.priorities);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.item_task, parent, false);
        }
        final Task t = getItem(position);

        CheckBox cb = convertView.findViewById(R.id.cbDone);
        TextView tvTitle = convertView.findViewById(R.id.tvTitle);
        TextView tvDue = convertView.findViewById(R.id.tvDue);
        TextView tvPriority = convertView.findViewById(R.id.tvPriority);

        tvTitle.setText(t.title);
        tvDue.setText(getContext().getString(R.string.due, t.dueDate));
        tvPriority.setText(priorityNames[t.priority]);
        tvPriority.setTextColor(ContextCompat.getColor(getContext(), priorityColor(t.priority)));

        if (t.done) {
            tvTitle.setPaintFlags(tvTitle.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        } else {
            tvTitle.setPaintFlags(tvTitle.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
        }

        cb.setOnCheckedChangeListener(null);
        cb.setChecked(t.done);
        cb.setOnClickListener(v -> {
            t.done = cb.isChecked();
            db.setDone(t.id, t.done);
            notifyDataSetChanged();
        });
        return convertView;
    }

    private int priorityColor(int p) {
        switch (p) {
            case 2:  return R.color.high;
            case 1:  return R.color.medium;
            default: return R.color.low;
        }
    }
}
