package com.ausu.studybuddy;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.Locale;

/** Activity 3: add a new task, or edit an existing one (when EXTRA_TASK_ID is passed). */
public class AddTaskActivity extends AppCompatActivity {

    private EditText etTitle, etDesc;
    private Button btnDate;
    private Spinner spPriority;
    private DbHelper db;
    private String dueDate = null;
    private long editId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        db = new DbHelper(this);
        etTitle = findViewById(R.id.etTitle);
        etDesc = findViewById(R.id.etDesc);
        btnDate = findViewById(R.id.btnDate);
        spPriority = findViewById(R.id.spPriority);
        Button btnSave = findViewById(R.id.btnSave);

        spPriority.setAdapter(ArrayAdapter.createFromResource(this, R.array.priorities,
                android.R.layout.simple_spinner_dropdown_item));

        editId = getIntent().getLongExtra(MainActivity.EXTRA_TASK_ID, -1);
        if (editId != -1) {
            setTitle(R.string.edit_task);
            Task t = db.getById(editId);
            if (t != null) {
                etTitle.setText(t.title);
                etDesc.setText(t.description);
                spPriority.setSelection(t.priority);
                dueDate = t.dueDate;
                btnDate.setText(dueDate);
            }
        } else {
            setTitle(R.string.add_task);
        }

        btnDate.setOnClickListener(v -> showDatePicker());
        btnSave.setOnClickListener(v -> saveTask());
    }

    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, (view, year, month, day) -> {
            dueDate = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day);
            btnDate.setText(dueDate);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void saveTask() {
        String title = etTitle.getText().toString().trim();
        if (title.isEmpty()) {
            etTitle.setError(getString(R.string.title_required));
            return;
        }
        if (dueDate == null) {
            Toast.makeText(this, R.string.date_required, Toast.LENGTH_SHORT).show();
            return;
        }
        String desc = etDesc.getText().toString().trim();
        int priority = spPriority.getSelectedItemPosition();

        if (editId == -1) {
            db.insert(new Task(title, desc, dueDate, priority));
        } else {
            Task t = db.getById(editId);
            t.title = title;
            t.description = desc;
            t.dueDate = dueDate;
            t.priority = priority;
            db.update(t);
        }
        Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
