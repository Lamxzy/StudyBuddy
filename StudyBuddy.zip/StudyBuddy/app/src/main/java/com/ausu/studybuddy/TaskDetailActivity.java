package com.ausu.studybuddy;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

/** Activity 4: shows one task with options to complete, edit or delete it. */
public class TaskDetailActivity extends AppCompatActivity {

    private DbHelper db;
    private long taskId;
    private Task task;

    private TextView tvTitle, tvDue, tvPriority, tvStatus, tvDesc;
    private Button btnToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_detail);
        setTitle(R.string.task_details);
        if (getSupportActionBar() != null) getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        db = new DbHelper(this);
        taskId = getIntent().getLongExtra(MainActivity.EXTRA_TASK_ID, -1);

        tvTitle = findViewById(R.id.tvDetailTitle);
        tvDue = findViewById(R.id.tvDetailDue);
        tvPriority = findViewById(R.id.tvDetailPriority);
        tvStatus = findViewById(R.id.tvDetailStatus);
        tvDesc = findViewById(R.id.tvDetailDesc);
        btnToggle = findViewById(R.id.btnToggle);
        Button btnEdit = findViewById(R.id.btnEdit);
        Button btnDelete = findViewById(R.id.btnDelete);

        btnToggle.setOnClickListener(v -> {
            task.done = !task.done;
            db.setDone(task.id, task.done);
            bind();
        });

        btnEdit.setOnClickListener(v -> {
            Intent i = new Intent(this, AddTaskActivity.class);
            i.putExtra(MainActivity.EXTRA_TASK_ID, taskId);
            startActivity(i);
        });

        btnDelete.setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setMessage(R.string.confirm_delete)
                        .setPositiveButton(R.string.delete, (d, w) -> {
                            db.delete(taskId);
                            Toast.makeText(this, R.string.deleted, Toast.LENGTH_SHORT).show();
                            finish();
                        })
                        .setNegativeButton(R.string.cancel, null)
                        .show());
    }

    @Override
    protected void onResume() {
        super.onResume();
        task = db.getById(taskId);
        if (task == null) { finish(); return; }
        bind();
    }

    private void bind() {
        String[] names = getResources().getStringArray(R.array.priorities);
        tvTitle.setText(task.title);
        tvDue.setText(getString(R.string.due, task.dueDate));
        tvPriority.setText(getString(R.string.priority) + ": " + names[task.priority]);
        tvStatus.setText(task.done ? R.string.status_done : R.string.status_pending);
        tvDesc.setText(task.description == null || task.description.isEmpty()
                ? getString(R.string.no_description) : task.description);
        btnToggle.setText(task.done ? R.string.mark_pending : R.string.mark_done);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
