package com.ausu.studybuddy;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

/** Activity 2: shows the list of all tasks. */
public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_TASK_ID = "task_id";

    private DbHelper db;
    private ListView listTasks;
    private TextView tvEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle(R.string.my_tasks);

        db = new DbHelper(this);
        listTasks = findViewById(R.id.listTasks);
        tvEmpty = findViewById(R.id.tvEmpty);
        FloatingActionButton fab = findViewById(R.id.fabAdd);

        fab.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, AddTaskActivity.class)));

        listTasks.setOnItemClickListener((parent, view, position, id) -> {
            Task t = (Task) parent.getItemAtPosition(position);
            Intent i = new Intent(MainActivity.this, TaskDetailActivity.class);
            i.putExtra(EXTRA_TASK_ID, t.id);
            startActivity(i);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        List<Task> tasks = db.getAll();
        listTasks.setAdapter(new TaskAdapter(this, tasks, db));
        tvEmpty.setVisibility(tasks.isEmpty() ? TextView.VISIBLE : TextView.GONE);
    }
}
