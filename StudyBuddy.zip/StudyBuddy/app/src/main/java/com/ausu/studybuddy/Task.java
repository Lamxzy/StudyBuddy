package com.ausu.studybuddy;

public class Task {
    public long id;
    public String title;
    public String description;
    public String dueDate;   // yyyy-MM-dd
    public int priority;     // 0 = Low, 1 = Medium, 2 = High
    public boolean done;

    public Task() { }

    public Task(String title, String description, String dueDate, int priority) {
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.priority = priority;
        this.done = false;
    }
}
